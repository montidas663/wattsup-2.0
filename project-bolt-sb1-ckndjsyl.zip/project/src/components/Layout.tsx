import React from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { Home, Tablet as DeviceTablet, LineChart, Lightbulb, Settings, Menu, X, Bell, ChevronDown, LogOut, User, Battery } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { useUser } from '../contexts/UserContext';
import { useEnergyData } from '../contexts/EnergyDataContext';

const Layout: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  const { user } = useUser();
  const { refreshData, isLoading } = useEnergyData();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = React.useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const navigation = [
    { name: 'Dashboard', path: '/', icon: Home },
    { name: 'Devices', path: '/devices', icon: DeviceTablet },
    { name: 'Analytics', path: '/analytics', icon: LineChart },
    { name: 'Recommendations', path: '/recommendations', icon: Lightbulb },
    { name: 'Settings', path: '/settings', icon: Settings },
  ];

  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  const toggleUserMenu = () => setIsUserMenuOpen(!isUserMenuOpen);

  // Get the page title from the current path
  const getPageTitle = () => {
    const currentRoute = navigation.find(item => item.path === location.pathname);
    return currentRoute?.name || 'Dashboard';
  };

  return (
    <div className="min-h-screen flex flex-col bg-neutral-50 dark:bg-neutral-900 text-neutral-900 dark:text-white">
      {/* Top navigation bar */}
      <header className="bg-white dark:bg-neutral-800 border-b border-neutral-200 dark:border-neutral-700 sticky top-0 z-10">
        <div className="mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              {/* Logo */}
              <div className="flex-shrink-0 flex items-center">
                <div className="flex items-center">
                  <Battery className="h-8 w-8 text-primary-500" />
                  <span className="ml-2 text-xl font-bold">WattsUp</span>
                </div>
              </div>
              
              {/* Desktop Navigation */}
              <nav className="hidden md:ml-10 md:flex md:space-x-8">
                {navigation.map((item) => (
                  <button
                    key={item.name}
                    className={`
                      inline-flex items-center px-1 pt-1 text-sm font-medium border-b-2 transition-colors
                      ${location.pathname === item.path 
                        ? 'border-primary-500 text-primary-600 dark:border-primary-400 dark:text-primary-400' 
                        : 'border-transparent text-neutral-500 hover:border-neutral-300 hover:text-neutral-700 dark:text-neutral-400 dark:hover:text-neutral-300'}
                    `}
                    onClick={() => navigate(item.path)}
                  >
                    <item.icon className="h-4 w-4 mr-2" />
                    {item.name}
                  </button>
                ))}
              </nav>
            </div>
            
            {/* Right side controls */}
            <div className="flex items-center">
              {/* Refresh button */}
              <button 
                onClick={refreshData}
                disabled={isLoading}
                className="ml-3 p-1 rounded-full text-neutral-500 hover:text-neutral-700 dark:text-neutral-400 dark:hover:text-neutral-300 focus:outline-none"
              >
                <span className="sr-only">Refresh Data</span>
                <svg 
                  className={`h-5 w-5 ${isLoading ? 'animate-spin' : ''}`} 
                  xmlns="http://www.w3.org/2000/svg" 
                  fill="none" 
                  viewBox="0 0 24 24" 
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
              </button>
              
              {/* Notifications */}
              <button className="ml-3 p-1 rounded-full text-neutral-500 hover:text-neutral-700 dark:text-neutral-400 dark:hover:text-neutral-300 focus:outline-none">
                <span className="sr-only">View notifications</span>
                <Bell className="h-5 w-5" />
              </button>
              
              {/* Theme toggle */}
              <button 
                onClick={toggleTheme} 
                className="ml-3 p-1 rounded-full text-neutral-500 hover:text-neutral-700 dark:text-neutral-400 dark:hover:text-neutral-300 focus:outline-none"
              >
                <span className="sr-only">Toggle theme</span>
                {theme === 'dark' ? (
                  <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
                  </svg>
                ) : (
                  <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
                  </svg>
                )}
              </button>
              
              {/* Profile dropdown */}
              <div className="ml-3 relative">
                <div>
                  <button 
                    onClick={toggleUserMenu}
                    className="flex text-sm rounded-full focus:outline-none focus:ring-2 focus:ring-primary-500"
                  >
                    <span className="sr-only">Open user menu</span>
                    <div className="h-8 w-8 rounded-full overflow-hidden">
                      <img 
                        className="h-full w-full object-cover" 
                        src={user?.avatarUrl} 
                        alt={user?.name} 
                      />
                    </div>
                    <ChevronDown className="ml-1 h-5 w-5 text-neutral-400" />
                  </button>
                </div>
                
                {isUserMenuOpen && (
                  <div 
                    className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg py-1 bg-white dark:bg-neutral-800 ring-1 ring-black ring-opacity-5 focus:outline-none"
                    role="menu"
                  >
                    <div className="px-4 py-3 border-b border-neutral-200 dark:border-neutral-700">
                      <p className="text-sm font-medium">{user?.name}</p>
                      <p className="text-xs text-neutral-500 dark:text-neutral-400">{user?.email}</p>
                    </div>
                    <button 
                      className="flex items-center w-full px-4 py-2 text-sm text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700"
                      onClick={() => {
                        setIsUserMenuOpen(false);
                        navigate('/settings');
                      }}
                    >
                      <User className="mr-3 h-4 w-4" />
                      Profile
                    </button>
                    <button 
                      className="flex items-center w-full px-4 py-2 text-sm text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700"
                      onClick={() => setIsUserMenuOpen(false)}
                    >
                      <LogOut className="mr-3 h-4 w-4" />
                      Sign out
                    </button>
                  </div>
                )}
              </div>
              
              {/* Mobile menu button */}
              <button 
                className="ml-3 md:hidden p-1 rounded-full text-neutral-500 hover:text-neutral-700 dark:text-neutral-400 dark:hover:text-neutral-300 focus:outline-none"
                onClick={toggleMobileMenu}
              >
                <span className="sr-only">Open main menu</span>
                {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </button>
            </div>
          </div>
        </div>
        
        {/* Mobile menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden">
            <div className="pt-2 pb-3 space-y-1">
              {navigation.map((item) => (
                <button
                  key={item.name}
                  className={`
                    flex items-center px-4 py-2 text-base font-medium w-full transition-colors
                    ${location.pathname === item.path 
                      ? 'bg-primary-50 border-l-4 border-primary-500 text-primary-700 dark:bg-primary-900/20 dark:text-primary-300' 
                      : 'text-neutral-600 hover:bg-neutral-100 hover:text-neutral-800 dark:text-neutral-300 dark:hover:bg-neutral-800'}
                  `}
                  onClick={() => {
                    navigate(item.path);
                    setIsMobileMenuOpen(false);
                  }}
                >
                  <item.icon className="h-5 w-5 mr-3" />
                  {item.name}
                </button>
              ))}
            </div>
          </div>
        )}
      </header>

      {/* Page content */}
      <main className="flex-1 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-neutral-900 dark:text-white">{getPageTitle()}</h1>
          </div>
          <div>
            <Outlet />
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white dark:bg-neutral-800 border-t border-neutral-200 dark:border-neutral-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="py-4 text-center text-sm text-neutral-500 dark:text-neutral-400">
            <p>&copy; 2025 WattsUp Energy Monitoring. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;