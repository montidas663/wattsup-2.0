import React, { useMemo } from 'react';
import { Doughnut } from 'react-chartjs-2';
import { DeviceUsage } from '../types/energy';
import { useTheme } from '../contexts/ThemeContext';

interface UsageBreakdownProps {
  deviceUsage: DeviceUsage[];
}

const UsageBreakdown: React.FC<UsageBreakdownProps> = ({ deviceUsage }) => {
  const { theme } = useTheme();
  
  // Define colors for each device type
  const typeColors = {
    lighting: '#10B981', // Primary green
    hvac: '#3B82F6', // Secondary blue
    kitchen: '#F59E0B', // Accent yellow
    entertainment: '#8B5CF6', // Purple
    office: '#EC4899', // Pink
    other: '#6B7280', // Gray
  };
  
  const chartData = useMemo(() => {
    // Filter out devices with 0 usage
    const activeDevices = deviceUsage.filter(d => d.percentage > 0);
    
    // Sort by percentage (highest first)
    const sortedDevices = [...activeDevices].sort((a, b) => b.percentage - a.percentage);
    
    // Cap at 5 devices, group the rest as "Other"
    let finalData;
    if (sortedDevices.length > 5) {
      const topDevices = sortedDevices.slice(0, 4);
      const otherDevices = sortedDevices.slice(4);
      
      const otherPercentage = otherDevices.reduce((sum, device) => sum + device.percentage, 0);
      const otherKWh = otherDevices.reduce((sum, device) => sum + device.kWh, 0);
      
      finalData = [
        ...topDevices,
        {
          deviceId: 'other',
          name: 'Other Devices',
          type: 'other',
          percentage: otherPercentage,
          kWh: otherKWh,
          cost: otherDevices.reduce((sum, device) => sum + device.cost, 0)
        }
      ];
    } else {
      finalData = sortedDevices;
    }
    
    // Prepare chart data
    const labels = finalData.map(d => d.name);
    const percentages = finalData.map(d => d.percentage);
    const colors = finalData.map(d => {
      const type = d.type as keyof typeof typeColors;
      return typeColors[type] || typeColors.other;
    });
    
    // Text colors based on theme
    const textColor = theme === 'dark' ? 'rgba(255, 255, 255, 0.7)' : 'rgba(0, 0, 0, 0.7)';
    
    return {
      data: {
        labels,
        datasets: [
          {
            data: percentages,
            backgroundColor: colors,
            borderColor: theme === 'dark' ? '#1E293B' : '#FFFFFF',
            borderWidth: 2,
            hoverOffset: 15,
          }
        ]
      },
      devices: finalData,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          },
          tooltip: {
            backgroundColor: theme === 'dark' ? 'rgba(30, 41, 59, 0.8)' : 'rgba(255, 255, 255, 0.8)',
            titleColor: theme === 'dark' ? '#fff' : '#000',
            bodyColor: theme === 'dark' ? '#e2e8f0' : '#334155',
            borderColor: theme === 'dark' ? 'rgba(255, 255, 255, 0.2)' : 'rgba(0, 0, 0, 0.1)',
            borderWidth: 1,
            padding: 10,
            callbacks: {
              label: function(context: any) {
                const label = context.label || '';
                const value = context.parsed || 0;
                const device = finalData[context.dataIndex];
                return [
                  `${label}: ${value.toFixed(1)}%`,
                  `Energy: ${device.kWh.toFixed(2)} kWh`,
                  `Cost: $${device.cost.toFixed(2)}`
                ];
              }
            }
          },
        },
        cutout: '70%',
        animation: {
          animateScale: true,
          animateRotate: true
        }
      }
    };
  }, [deviceUsage, theme]);
  
  return (
    <div className="card h-full">
      <h3 className="text-lg font-semibold mb-4">Device Breakdown</h3>
      
      <div className="flex flex-col sm:flex-row h-full">
        {/* Chart */}
        <div className="w-full sm:w-1/2 h-64 relative">
          <Doughnut 
            data={chartData.data}
            options={chartData.options as any}
          />
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="text-center">
              <div className="text-2xl font-bold text-neutral-800 dark:text-neutral-200">
                {chartData.devices.reduce((sum, device) => sum + device.kWh, 0).toFixed(1)}
              </div>
              <div className="text-sm text-neutral-500 dark:text-neutral-400">kWh today</div>
            </div>
          </div>
        </div>
        
        {/* Legend */}
        <div className="w-full sm:w-1/2 sm:pl-6 mt-4 sm:mt-0">
          <div className="space-y-3">
            {chartData.devices.map((device, index) => (
              <div key={device.deviceId} className="flex items-center">
                <div 
                  className="w-3 h-3 rounded-full mr-2" 
                  style={{ 
                    backgroundColor: (typeColors as any)[device.type] || typeColors.other 
                  }}
                ></div>
                <div className="flex-1 text-sm">{device.name}</div>
                <div className="text-sm font-medium">{device.percentage.toFixed(1)}%</div>
              </div>
            ))}
          </div>
          
          <div className="mt-6 pt-4 border-t border-neutral-200 dark:border-neutral-700">
            <div className="flex justify-between text-sm">
              <span className="text-neutral-500 dark:text-neutral-400">Total Cost Today</span>
              <span className="font-semibold">
                ${chartData.devices.reduce((sum, device) => sum + device.cost, 0).toFixed(2)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UsageBreakdown;