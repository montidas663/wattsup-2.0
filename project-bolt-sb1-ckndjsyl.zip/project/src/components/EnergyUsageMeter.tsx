import React from 'react';
import { useEnergyData } from '../contexts/EnergyDataContext';
import { Zap, Gauge, AlertTriangle, Check } from 'lucide-react';

const EnergyUsageMeter: React.FC = () => {
  const { currentUsage } = useEnergyData();
  
  // Calculate usage percentage compared to daily goal
  const usagePercentage = Math.min(100, (currentUsage.dailyTotal / currentUsage.dailyGoal) * 100);
  
  // Determine status based on percentage
  const getStatus = () => {
    if (usagePercentage < 70) return 'good';
    if (usagePercentage < 90) return 'warning';
    return 'critical';
  };
  
  const status = getStatus();
  
  // Get the right colors based on status
  const getStatusColors = () => {
    switch (status) {
      case 'good':
        return {
          text: 'text-success-500',
          bg: 'bg-success-500',
          icon: <Check className="w-5 h-5" />,
          message: 'Below daily target'
        };
      case 'warning':
        return {
          text: 'text-warning-500',
          bg: 'bg-warning-500',
          icon: <AlertTriangle className="w-5 h-5" />,
          message: 'Approaching daily target'
        };
      case 'critical':
        return {
          text: 'text-error-500',
          bg: 'bg-error-500',
          icon: <AlertTriangle className="w-5 h-5" />,
          message: 'Exceeded daily target'
        };
      default:
        return {
          text: 'text-success-500',
          bg: 'bg-success-500',
          icon: <Check className="w-5 h-5" />,
          message: 'Below daily target'
        };
    }
  };
  
  const statusColors = getStatusColors();
  
  return (
    <div className="card h-full">
      <div className="flex flex-col h-full">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Current Usage</h3>
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-neutral-100 dark:bg-neutral-700 text-neutral-800 dark:text-neutral-200">
            Live
          </span>
        </div>
        
        <div className="flex-1 flex flex-col items-center justify-center">
          {/* Gauge visualization */}
          <div className="relative w-48 h-24 mb-6">
            <div className="absolute inset-0 overflow-hidden">
              {/* Background arc */}
              <div className="absolute top-0 left-0 w-48 h-48 border-[16px] border-neutral-200 dark:border-neutral-700 rounded-full"></div>
              
              {/* Foreground arc - dynamic width based on percentage */}
              <div 
                className={`absolute top-0 left-0 w-48 h-48 border-[16px] ${statusColors.bg} rounded-full`} 
                style={{
                  clipPath: `polygon(24px 24px, 24px 24px, 24px 0px, ${usagePercentage}% 0px, ${usagePercentage}% 100%, 24px 100%)`
                }}
              ></div>
            </div>
            
            {/* Center display */}
            <div className="absolute inset-0 flex flex-col items-center justify-center pt-4">
              <div className="text-3xl font-bold flex items-center">
                <Zap className="w-6 h-6 text-primary-500 mr-1" />
                {currentUsage.watts.toLocaleString()}
                <span className="text-lg font-normal ml-1">W</span>
              </div>
              <div className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
                {currentUsage.kWh} kWh
              </div>
            </div>
          </div>
          
          {/* Stats */}
          <div className="grid grid-cols-2 gap-4 w-full">
            <div className="text-center">
              <div className="text-neutral-500 dark:text-neutral-400 text-xs mb-1">Voltage</div>
              <div className="text-lg font-medium">{currentUsage.voltage}V</div>
            </div>
            <div className="text-center">
              <div className="text-neutral-500 dark:text-neutral-400 text-xs mb-1">Amperage</div>
              <div className="text-lg font-medium">{currentUsage.amperage}A</div>
            </div>
          </div>
          
          {/* Daily progress */}
          <div className="w-full mt-6">
            <div className="flex justify-between text-sm mb-1">
              <span>Daily Usage</span>
              <span className="font-medium">
                {currentUsage.dailyTotal.toFixed(1)} / {currentUsage.dailyGoal} kWh
              </span>
            </div>
            <div className="w-full bg-neutral-200 dark:bg-neutral-700 rounded-full h-2.5">
              <div 
                className={`h-2.5 rounded-full ${statusColors.bg}`}
                style={{ width: `${usagePercentage}%` }}
              ></div>
            </div>
            <div className={`flex items-center mt-1.5 ${statusColors.text} text-xs`}>
              {statusColors.icon}
              <span className="ml-1">{statusColors.message}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EnergyUsageMeter;