import React from 'react';
import { EnergyTip } from '../types/energy';
import { 
  Lightbulb, 
  DollarSign, 
  ThermometerSun, 
  Plug, 
  PlugZap,
  MonitorSmartphone,
  Settings
} from 'lucide-react';

interface EnergyTipsProps {
  tips: EnergyTip[];
  limit?: number;
}

const EnergyTips: React.FC<EnergyTipsProps> = ({ tips, limit }) => {
  const displayTips = limit ? tips.slice(0, limit) : tips;
  
  const getTipIcon = (tip: EnergyTip) => {
    switch (tip.category) {
      case 'lighting':
        return <Lightbulb className="h-5 w-5" />;
      case 'hvac':
        return <ThermometerSun className="h-5 w-5" />;
      case 'appliance':
        return <PlugZap className="h-5 w-5" />;
      case 'office':
        return <MonitorSmartphone className="h-5 w-5" />;
      case 'general':
      default:
        return <Plug className="h-5 w-5" />;
    }
  };
  
  const getDifficultyClass = (difficulty: string) => {
    switch (difficulty) {
      case 'easy':
        return 'bg-success-500/10 text-success-500';
      case 'medium':
        return 'bg-warning-500/10 text-warning-500';
      case 'hard':
        return 'bg-error-500/10 text-error-500';
      default:
        return 'bg-neutral-500/10 text-neutral-500';
    }
  };
  
  return (
    <div className="space-y-4">
      {displayTips.map((tip) => (
        <div key={tip.id} className="card card-hoverable flex">
          <div className="mr-4 flex-shrink-0 bg-primary-100 dark:bg-primary-900/30 h-10 w-10 rounded-full flex items-center justify-center text-primary-600 dark:text-primary-400">
            {getTipIcon(tip)}
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between mb-1">
              <h4 className="font-medium text-neutral-900 dark:text-white">{tip.title}</h4>
              <span className={`text-xs px-2 py-0.5 rounded-full ${getDifficultyClass(tip.difficulty)}`}>
                {tip.difficulty}
              </span>
            </div>
            <p className="text-sm text-neutral-600 dark:text-neutral-300 mb-2">
              {tip.description}
            </p>
            <div className="flex justify-between items-center">
              <div className="flex items-center text-sm text-success-500">
                <DollarSign className="h-4 w-4 mr-1" />
                <span>Potential savings: ${tip.potentialSavings}/year</span>
              </div>
              <button className="text-secondary-500 hover:text-secondary-600 text-sm font-medium flex items-center">
                Learn more
                <svg className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      ))}
      
      {limit && tips.length > limit && (
        <div className="text-center">
          <button className="btn btn-secondary">
            View All Tips
          </button>
        </div>
      )}
    </div>
  );
};

export default EnergyTips;