import React, { useState } from 'react';
import { 
  Smartphone,
  RefrigeratorIcon,
  MonitorIcon, 
  AirVent, 
  WashingMachine,
  Droplet,
  Lightbulb
} from 'lucide-react';
import { Device } from '../types/energy';

interface DeviceListProps {
  devices: Device[];
  onDeviceClick?: (device: Device) => void;
}

const DeviceList: React.FC<DeviceListProps> = ({ devices, onDeviceClick }) => {
  const [sortBy, setSortBy] = useState<'name' | 'watts' | 'location'>('watts');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  
  const handleSort = (column: 'name' | 'watts' | 'location') => {
    if (sortBy === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(column);
      setSortDirection('asc');
    }
  };
  
  const getDeviceIcon = (device: Device) => {
    switch (device.type) {
      case 'lighting':
        return <Lightbulb size={20} />;
      case 'hvac':
        return <AirVent size={20} />;
      case 'kitchen':
        return <RefrigeratorIcon size={20} />;
      case 'entertainment':
        return <MonitorIcon size={20} />;
      case 'office':
        return <Smartphone size={20} />;
      case 'other':
        return device.name.includes('Washing') 
          ? <WashingMachine size={20} /> 
          : device.name.includes('Water') 
          ? <Droplet size={20} />
          : <Smartphone size={20} />;
      default:
        return <Smartphone size={20} />;
    }
  };
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'normal':
        return 'bg-success-500';
      case 'high':
        return 'bg-error-500';
      case 'low':
        return 'bg-warning-500';
      case 'offline':
        return 'bg-neutral-400';
      default:
        return 'bg-neutral-400';
    }
  };
  
  // Sort devices
  const sortedDevices = [...devices].sort((a, b) => {
    if (sortBy === 'name') {
      return sortDirection === 'asc' 
        ? a.name.localeCompare(b.name) 
        : b.name.localeCompare(a.name);
    } else if (sortBy === 'location') {
      return sortDirection === 'asc' 
        ? a.location.localeCompare(b.location) 
        : b.location.localeCompare(a.location);
    } else { // watts
      return sortDirection === 'asc' 
        ? a.watts - b.watts 
        : b.watts - a.watts;
    }
  });
  
  const SortIcon = () => (
    <svg 
      className="w-3 h-3 ml-1" 
      fill="none" 
      stroke="currentColor" 
      viewBox="0 0 24 24" 
      xmlns="http://www.w3.org/2000/svg"
    >
      {sortDirection === 'asc' ? (
        <path strokeLinecap="round\" strokeLinejoin="round\" strokeWidth="2\" d="M5 15l7-7 7 7" />
      ) : (
        <path strokeLinecap="round\" strokeLinejoin="round\" strokeWidth="2\" d="M19 9l-7 7-7-7" />
      )}
    </svg>
  );
  
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-neutral-200 dark:divide-neutral-700">
        <thead className="bg-neutral-50 dark:bg-neutral-800">
          <tr>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
              Status
            </th>
            <th 
              scope="col" 
              className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider cursor-pointer"
              onClick={() => handleSort('name')}
            >
              <div className="flex items-center">
                Device
                {sortBy === 'name' && <SortIcon />}
              </div>
            </th>
            <th 
              scope="col" 
              className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider cursor-pointer"
              onClick={() => handleSort('location')}
            >
              <div className="flex items-center">
                Location
                {sortBy === 'location' && <SortIcon />}
              </div>
            </th>
            <th 
              scope="col" 
              className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider cursor-pointer"
              onClick={() => handleSort('watts')}
            >
              <div className="flex items-center">
                Power
                {sortBy === 'watts' && <SortIcon />}
              </div>
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
              Efficiency
            </th>
          </tr>
        </thead>
        <tbody className="bg-white dark:bg-neutral-800 divide-y divide-neutral-200 dark:divide-neutral-700">
          {sortedDevices.map((device) => (
            <tr 
              key={device.id} 
              className={`hover:bg-neutral-50 dark:hover:bg-neutral-700 transition-colors ${onDeviceClick ? 'cursor-pointer' : ''}`}
              onClick={() => onDeviceClick && onDeviceClick(device)}
            >
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                  <div className={`flex-shrink-0 h-2.5 w-2.5 rounded-full ${getStatusColor(device.status)}`}></div>
                  <span className="ml-2 text-sm text-neutral-500 dark:text-neutral-400">
                    {device.isOn ? 'On' : 'Off'}
                  </span>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                  <div className="flex-shrink-0 h-8 w-8 bg-primary-100 dark:bg-primary-900 rounded-full flex items-center justify-center text-primary-600 dark:text-primary-400">
                    {getDeviceIcon(device)}
                  </div>
                  <div className="ml-3">
                    <div className="text-sm font-medium text-neutral-900 dark:text-white">
                      {device.name}
                    </div>
                  </div>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-neutral-900 dark:text-white">{device.location}</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm">
                <span className={`font-medium ${device.isOn ? 'text-neutral-900 dark:text-white' : 'text-neutral-500 dark:text-neutral-400'}`}>
                  {device.isOn ? `${device.watts}W` : '0W'}
                </span>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span className={`px-2 py-1 text-xs rounded-full ${
                  device.energyEfficiency.startsWith('A') 
                    ? 'bg-success-500/10 text-success-500' 
                    : device.energyEfficiency === 'B'
                    ? 'bg-primary-500/10 text-primary-500'
                    : 'bg-warning-500/10 text-warning-500'
                }`}>
                  {device.energyEfficiency}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default DeviceList;