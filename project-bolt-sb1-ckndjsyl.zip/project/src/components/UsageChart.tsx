import React, { useMemo } from 'react';
import { Line } from 'react-chartjs-2';
import { DailyUsage } from '../types/energy';
import { useTheme } from '../contexts/ThemeContext';
import { format, parseISO } from 'date-fns';

interface UsageChartProps {
  data: DailyUsage[];
  timeframe: 'daily' | 'weekly' | 'monthly' | 'yearly';
  showCost?: boolean;
}

const UsageChart: React.FC<UsageChartProps> = ({ data, timeframe, showCost = false }) => {
  const { theme } = useTheme();
  
  // Format dates based on timeframe
  const formatDate = (dateStr: string) => {
    try {
      const date = timeframe === 'yearly' ? new Date(dateStr) : parseISO(dateStr);
      switch (timeframe) {
        case 'daily':
          return format(date, 'MMM d');
        case 'weekly':
          return format(date, 'MMM d');
        case 'monthly':
          return format(date, 'MMM yyyy');
        case 'yearly':
          return dateStr; // It's already a year
        default:
          return dateStr;
      }
    } catch (e) {
      return dateStr;
    }
  };

  const chartData = useMemo(() => {
    const labels = data.map(item => formatDate(item.date));
    const usageData = data.map(item => item.kWh);
    const costData = data.map(item => item.cost);
    
    const gridColor = theme === 'dark' ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)';
    const textColor = theme === 'dark' ? 'rgba(255, 255, 255, 0.7)' : 'rgba(0, 0, 0, 0.7)';
    
    return {
      labels,
      datasets: [
        {
          label: 'Energy (kWh)',
          data: usageData,
          borderColor: '#10B981',
          backgroundColor: 'rgba(16, 185, 129, 0.1)',
          fill: true,
          tension: 0.3,
          borderWidth: 2,
          pointRadius: 3,
          pointHoverRadius: 5,
        },
        ...(showCost ? [{
          label: 'Cost ($)',
          data: costData,
          borderColor: '#3B82F6',
          backgroundColor: 'rgba(59, 130, 246, 0.1)',
          fill: true,
          tension: 0.3,
          borderWidth: 2,
          pointRadius: 3,
          pointHoverRadius: 5,
          yAxisID: 'y1',
        }] : []),
      ],
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: {
            grid: {
              display: true,
              color: gridColor,
            },
            ticks: {
              color: textColor,
            },
          },
          y: {
            grid: {
              display: true,
              color: gridColor,
            },
            ticks: {
              color: textColor,
              callback: (value: any) => `${value} kWh`,
            },
            beginAtZero: true,
          },
          ...(showCost ? {
            y1: {
              position: 'right',
              grid: {
                display: false,
              },
              ticks: {
                color: textColor,
                callback: (value: any) => `$${value}`,
              },
              beginAtZero: true,
            },
          } : {}),
        },
        plugins: {
          legend: {
            display: true,
            labels: {
              color: textColor,
            },
          },
          tooltip: {
            backgroundColor: theme === 'dark' ? 'rgba(30, 41, 59, 0.8)' : 'rgba(255, 255, 255, 0.8)',
            titleColor: theme === 'dark' ? '#fff' : '#000',
            bodyColor: theme === 'dark' ? '#e2e8f0' : '#334155',
            borderColor: theme === 'dark' ? 'rgba(255, 255, 255, 0.2)' : 'rgba(0, 0, 0, 0.1)',
            borderWidth: 1,
            padding: 10,
            displayColors: true,
            callbacks: {
              label: function(context: any) {
                const label = context.dataset.label || '';
                const value = context.parsed.y;
                if (label === 'Energy (kWh)') {
                  return `${label}: ${value.toFixed(2)} kWh`;
                } else if (label === 'Cost ($)') {
                  return `${label}: $${value.toFixed(2)}`;
                }
                return `${label}: ${value}`;
              }
            }
          }
        },
        animation: {
          duration: 1000,
        },
      },
    };
  }, [data, theme, showCost]);

  return (
    <div className="h-72 chart-container">
      <Line 
        data={chartData} 
        options={chartData.options as any}
      />
    </div>
  );
};

export default UsageChart;