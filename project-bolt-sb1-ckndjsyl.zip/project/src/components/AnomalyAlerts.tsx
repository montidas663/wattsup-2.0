import React from 'react';
import { AlertTriangle, Info, CheckCircle, Clock } from 'lucide-react';

interface Anomaly {
  id: string;
  deviceId: string;
  deviceName: string;
  timestamp: string;
  description: string;
  severity: 'low' | 'medium' | 'high';
  watts: number;
  normalWatts: number;
  percentageIncrease: number;
  isResolved: boolean;
}

interface AnomalyAlertsProps {
  anomalies: Anomaly[];
}

const AnomalyAlerts: React.FC<AnomalyAlertsProps> = ({ anomalies }) => {
  if (anomalies.length === 0) {
    return (
      <div className="card h-full flex flex-col justify-center items-center py-8">
        <CheckCircle className="h-12 w-12 text-success-500 mb-3" />
        <h3 className="text-lg font-medium text-neutral-900 dark:text-white">All Systems Normal</h3>
        <p className="text-neutral-500 dark:text-neutral-400 text-center max-w-xs mt-2">
          No anomalies detected in your energy usage patterns. Your devices are operating efficiently.
        </p>
      </div>
    );
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'bg-error-500 text-white';
      case 'medium':
        return 'bg-warning-500 text-white';
      case 'low':
        return 'bg-primary-500 text-white';
      default:
        return 'bg-neutral-500 text-white';
    }
  };

  const formatTimestamp = (timestamp: string) => {
    try {
      const date = new Date(timestamp);
      return date.toLocaleString('en-US', { 
        month: 'short',
        day: 'numeric', 
        hour: '2-digit', 
        minute: '2-digit'
      });
    } catch (e) {
      return timestamp;
    }
  };

  return (
    <div className="card h-full">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold flex items-center">
          <AlertTriangle className="h-5 w-5 text-warning-500 mr-2" />
          Anomaly Alerts
        </h3>
        {anomalies.length > 0 && (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-error-500/10 text-error-500">
            {anomalies.filter(a => !a.isResolved).length} Active
          </span>
        )}
      </div>

      <div className="space-y-4">
        {anomalies.map((anomaly) => (
          <div 
            key={anomaly.id}
            className={`rounded-lg border ${anomaly.isResolved 
              ? 'border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800/50' 
              : 'border-warning-200 dark:border-warning-900/30 bg-warning-50 dark:bg-warning-900/10'
            } p-4`}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center">
                <span className={`inline-flex items-center justify-center h-6 w-6 rounded-full ${getSeverityColor(anomaly.severity)} mr-2 text-xs`}>
                  {anomaly.severity === 'high' ? '!' : 'i'}
                </span>
                <h4 className="font-medium">{anomaly.deviceName}</h4>
              </div>
              <div className="text-xs flex items-center text-neutral-500 dark:text-neutral-400">
                <Clock className="h-3 w-3 mr-1" />
                {formatTimestamp(anomaly.timestamp)}
              </div>
            </div>
            
            <p className="text-sm text-neutral-600 dark:text-neutral-300 mb-3">
              {anomaly.description}: {anomaly.percentageIncrease.toFixed(0)}% increase in power consumption 
              ({anomaly.normalWatts}W → {anomaly.watts}W)
            </p>
            
            <div className="flex justify-between items-center">
              <div className={`text-xs ${anomaly.isResolved ? 'text-success-500' : 'text-warning-500'}`}>
                {anomaly.isResolved 
                  ? <span className="flex items-center"><CheckCircle className="h-3 w-3 mr-1" /> Resolved</span>
                  : <span className="flex items-center"><Info className="h-3 w-3 mr-1" /> Requires attention</span>
                }
              </div>
              
              <button className="text-secondary-500 hover:text-secondary-600 text-sm font-medium">
                {anomaly.isResolved ? 'View Details' : 'Investigate'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AnomalyAlerts;