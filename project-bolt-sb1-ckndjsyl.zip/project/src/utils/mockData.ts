import { format, subDays, subMonths, subWeeks, eachDayOfInterval } from 'date-fns';
import { 
  EnergyUsage, 
  DailyUsage, 
  Device, 
  DeviceUsage, 
  EnergyTip,
  Anomaly
} from '../types/energy';

// Generate realistic energy usage data with randomness within constraints
const randomInt = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1) + min);
const randomFloat = (min: number, max: number) => parseFloat((Math.random() * (max - min) + min).toFixed(2));

// Generate current usage data with some randomness
const generateCurrentUsage = (previous?: EnergyUsage): EnergyUsage => {
  const baseWatts = previous ? previous.watts : 720;
  const variance = previous ? randomFloat(-50, 50) : 0;
  const watts = Math.max(300, Math.min(2000, baseWatts + variance));
  
  const voltage = randomFloat(117, 123);
  const amperage = parseFloat((watts / voltage).toFixed(2));
  const kWh = parseFloat((watts / 1000).toFixed(2));
  
  const dailyTotal = previous ? previous.dailyTotal + kWh / 24 : randomFloat(8, 12);
  const dailyGoal = previous?.dailyGoal || 10;
  
  const weeklyTotal = previous?.weeklyTotal || randomFloat(60, 80);
  const monthlyTotal = previous?.monthlyTotal || randomFloat(250, 300);
  const monthlyCost = parseFloat((monthlyTotal * 0.15).toFixed(2));

  return {
    watts,
    voltage,
    amperage,
    kWh,
    dailyTotal,
    dailyGoal,
    weeklyTotal,
    monthlyTotal,
    monthlyCost
  };
};

// Generate daily usage history
const generateDailyUsage = (): DailyUsage[] => {
  const today = new Date();
  const days = 14; // Two weeks of data
  
  return eachDayOfInterval({
    start: subDays(today, days - 1),
    end: today
  }).map((date, index) => {
    const isWeekend = [0, 6].includes(date.getDay());
    const baseUsage = isWeekend ? randomFloat(9, 14) : randomFloat(7, 12);
    
    // Add some trends - usage generally increases over the past days
    const trendFactor = 1 + (index / days) * 0.3;
    
    return {
      date: format(date, 'yyyy-MM-dd'),
      kWh: parseFloat((baseUsage * trendFactor).toFixed(2)),
      cost: parseFloat((baseUsage * trendFactor * 0.15).toFixed(2)),
      compared: index > 0 ? randomFloat(-15, 20) : 0
    };
  });
};

// Generate weekly rollup
const generateWeeklyUsage = (): DailyUsage[] => {
  const today = new Date();
  const weeks = 12; // 12 weeks (3 months) of data
  
  return Array.from({ length: weeks }).map((_, i) => {
    const weekStart = subWeeks(today, weeks - 1 - i);
    const baseUsage = randomFloat(45, 70);
    // Summer months use more energy for cooling
    const seasonalFactor = weekStart.getMonth() >= 5 && weekStart.getMonth() <= 8 ? 1.3 : 1;
    
    return {
      date: format(weekStart, 'yyyy-MM-dd'),
      kWh: parseFloat((baseUsage * seasonalFactor).toFixed(2)),
      cost: parseFloat((baseUsage * seasonalFactor * 0.15).toFixed(2))
    };
  });
};

// Generate monthly rollup
const generateMonthlyUsage = (): DailyUsage[] => {
  const today = new Date();
  const months = 12; // Last 12 months
  
  return Array.from({ length: months }).map((_, i) => {
    const monthStart = subMonths(today, months - 1 - i);
    const baseUsage = randomFloat(200, 350);
    
    // Summer months use more energy, winter months slightly more too
    const month = monthStart.getMonth();
    let seasonalFactor = 1;
    if (month >= 5 && month <= 8) seasonalFactor = 1.4; // Summer
    else if (month >= 11 || month <= 1) seasonalFactor = 1.2; // Winter
    
    return {
      date: format(monthStart, 'yyyy-MM'),
      kWh: parseFloat((baseUsage * seasonalFactor).toFixed(2)),
      cost: parseFloat((baseUsage * seasonalFactor * 0.15).toFixed(2))
    };
  });
};

// Generate yearly rollup
const generateYearlyUsage = (): DailyUsage[] => {
  const thisYear = new Date().getFullYear();
  
  return Array.from({ length: 5 }).map((_, i) => {
    const year = thisYear - 4 + i;
    // Slightly increasing year over year with some variance
    const baseUsage = 2800 + i * 120 + randomFloat(-100, 100);
    
    return {
      date: year.toString(),
      kWh: parseFloat(baseUsage.toFixed(2)),
      cost: parseFloat((baseUsage * 0.15).toFixed(2))
    };
  });
};

// Generate device data
const generateDevices = (): Device[] => [
  {
    id: 'dev1',
    name: 'Kitchen Refrigerator',
    type: 'kitchen',
    location: 'Kitchen',
    isOn: true,
    watts: randomInt(100, 180),
    icon: 'refrigerator',
    energyEfficiency: 'A+',
    status: 'normal',
    lastUpdated: new Date().toISOString()
  },
  {
    id: 'dev2',
    name: 'Living Room TV',
    type: 'entertainment',
    location: 'Living Room',
    isOn: false,
    watts: 0,
    icon: 'tv',
    energyEfficiency: 'A++',
    status: 'normal',
    lastUpdated: new Date().toISOString()
  },
  {
    id: 'dev3',
    name: 'HVAC System',
    type: 'hvac',
    location: 'Whole House',
    isOn: true,
    watts: randomInt(800, 1200),
    icon: 'air-conditioner',
    energyEfficiency: 'A',
    status: 'high',
    lastUpdated: new Date().toISOString()
  },
  {
    id: 'dev4',
    name: 'Home Office Computer',
    type: 'office',
    location: 'Office',
    isOn: true,
    watts: randomInt(150, 250),
    icon: 'computer',
    energyEfficiency: 'B',
    status: 'normal',
    lastUpdated: new Date().toISOString()
  },
  {
    id: 'dev5',
    name: 'Washing Machine',
    type: 'other',
    location: 'Laundry Room',
    isOn: false,
    watts: 0,
    icon: 'washing-machine',
    energyEfficiency: 'A+++',
    status: 'normal',
    lastUpdated: new Date().toISOString()
  },
  {
    id: 'dev6',
    name: 'Kitchen Lights',
    type: 'lighting',
    location: 'Kitchen',
    isOn: true,
    watts: randomInt(30, 60),
    icon: 'lightbulb',
    energyEfficiency: 'A++',
    status: 'normal',
    lastUpdated: new Date().toISOString()
  },
  {
    id: 'dev7',
    name: 'Electric Water Heater',
    type: 'other',
    location: 'Basement',
    isOn: true,
    watts: randomInt(300, 450),
    icon: 'droplet',
    energyEfficiency: 'C',
    status: 'normal',
    lastUpdated: new Date().toISOString()
  }
];

// Generate device usage breakdown
const generateDeviceUsage = (devices: Device[]): DeviceUsage[] => {
  const totalUsage = devices.reduce((sum, device) => sum + device.watts, 0) || 1; // Avoid division by zero
  
  return devices.map(device => {
    const kWh = device.isOn ? parseFloat((device.watts / 1000 * 24).toFixed(2)) : 0;
    const percentage = device.isOn ? parseFloat(((device.watts / totalUsage) * 100).toFixed(1)) : 0;
    
    return {
      deviceId: device.id,
      name: device.name,
      type: device.type,
      kWh,
      percentage,
      cost: parseFloat((kWh * 0.15).toFixed(2))
    };
  });
};

// Generate energy-saving tips
const generateTips = (): EnergyTip[] => [
  {
    id: 'tip1',
    title: 'Lower HVAC Usage',
    description: 'Reduce your HVAC energy consumption by setting your thermostat 1-2 degrees higher in summer and lower in winter.',
    potentialSavings: 83,
    difficulty: 'easy',
    icon: 'thermometer',
    category: 'hvac'
  },
  {
    id: 'tip2',
    title: 'Upgrade Refrigerator',
    description: 'Consider replacing your refrigerator with an Energy Star rated model to reduce electricity consumption.',
    potentialSavings: 147,
    difficulty: 'hard',
    icon: 'refrigerator',
    category: 'appliance'
  },
  {
    id: 'tip3',
    title: 'Switch to LED Lighting',
    description: 'Replace remaining incandescent bulbs with LED alternatives to save up to 80% on lighting costs.',
    potentialSavings: 62,
    difficulty: 'easy',
    icon: 'lightbulb',
    category: 'lighting'
  },
  {
    id: 'tip4',
    title: 'Unplug Devices',
    description: 'Unplug electronic devices or use a power strip to eliminate vampire power draw when not in use.',
    potentialSavings: 76,
    difficulty: 'medium',
    icon: 'plug',
    category: 'general'
  },
  {
    id: 'tip5',
    title: 'Optimize Computer Usage',
    description: 'Configure your computer to use sleep mode when inactive for more than 15 minutes.',
    potentialSavings: 35,
    difficulty: 'easy',
    icon: 'computer',
    category: 'office'
  }
];

// Generate anomalies
const generateAnomalies = (devices: Device[]): Anomaly[] => {
  const anomalies: Anomaly[] = [
    {
      id: 'anom1',
      deviceId: 'dev3',
      deviceName: 'HVAC System',
      timestamp: subHours(new Date(), 3).toISOString(),
      description: 'Unusual power consumption detected',
      severity: 'high',
      watts: 1450,
      normalWatts: 950,
      percentageIncrease: 52.6,
      isResolved: false
    },
    {
      id: 'anom2',
      deviceId: 'dev1',
      deviceName: 'Kitchen Refrigerator',
      timestamp: subDays(new Date(), 2).toISOString(),
      description: 'Extended cooling cycle detected',
      severity: 'medium',
      watts: 210,
      normalWatts: 150,
      percentageIncrease: 40,
      isResolved: true
    }
  ];
  
  return anomalies;
};

// Helper function - subtract hours from date
function subHours(date: Date, hours: number): Date {
  return new Date(date.getTime() - hours * 60 * 60 * 1000);
}

export const generateMockEnergyData = (previousData?: any) => {
  const currentUsage = generateCurrentUsage(previousData?.currentUsage);
  const devices = generateDevices();
  const deviceUsage = generateDeviceUsage(devices);
  
  return {
    currentUsage,
    dailyUsage: previousData?.dailyUsage || generateDailyUsage(),
    weeklyUsage: previousData?.weeklyUsage || generateWeeklyUsage(),
    monthlyUsage: previousData?.monthlyUsage || generateMonthlyUsage(),
    yearlyUsage: previousData?.yearlyUsage || generateYearlyUsage(),
    devices,
    deviceUsage,
    tips: generateTips(),
    anomalies: generateAnomalies(devices)
  };
};