import React, { useState } from 'react';
import { useEnergyData } from '../contexts/EnergyDataContext';
import DeviceList from '../components/DeviceList';
import { 
  Search, 
  Settings, 
  RefreshCcw,
  Plus,
  Power,
  Zap,
  Battery,
  Clock
} from 'lucide-react';
import { Device } from '../types/energy';

const Devices: React.FC = () => {
  const { devices, refreshData, isLoading } = useEnergyData();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);
  const [showDeviceDetail, setShowDeviceDetail] = useState(false);

  // Filter devices based on search query
  const filteredDevices = devices.filter(device => 
    device.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    device.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleDeviceClick = (device: Device) => {
    setSelectedDevice(device);
    setShowDeviceDetail(true);
  };

  // Get the total number of devices that are currently on
  const activeDevices = devices.filter(device => device.isOn).length;

  // Calculate total power consumption of all devices
  const totalPower = devices.reduce((sum, device) => sum + device.watts, 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4">
        <div>
          <h2 className="text-2xl font-bold">Connected Devices</h2>
          <p className="text-neutral-500 dark:text-neutral-400 mt-1">
            {devices.length} total devices, {activeDevices} currently active
          </p>
        </div>
        <div className="mt-3 sm:mt-0 flex space-x-2">
          <button 
            onClick={refreshData}
            disabled={isLoading}
            className="btn btn-secondary"
          >
            <RefreshCcw className="h-4 w-4 mr-2" />
            {isLoading ? 'Refreshing...' : 'Refresh'}
          </button>
          <button className="btn btn-primary">
            <Plus className="h-4 w-4 mr-2" />
            Add Device
          </button>
        </div>
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="card bg-white dark:bg-neutral-800 p-4">
          <div className="flex items-center">
            <div className="p-2 rounded-lg bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400 mr-3">
              <Zap className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">Total Power</p>
              <p className="text-lg font-semibold">{totalPower} watts</p>
            </div>
          </div>
        </div>
        
        <div className="card bg-white dark:bg-neutral-800 p-4">
          <div className="flex items-center">
            <div className="p-2 rounded-lg bg-secondary-100 dark:bg-secondary-900/30 text-secondary-600 dark:text-secondary-400 mr-3">
              <Power className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">Active Devices</p>
              <p className="text-lg font-semibold">{activeDevices} / {devices.length}</p>
            </div>
          </div>
        </div>
        
        <div className="card bg-white dark:bg-neutral-800 p-4">
          <div className="flex items-center">
            <div className="p-2 rounded-lg bg-accent-100 dark:bg-accent-900/30 text-accent-600 dark:text-accent-400 mr-3">
              <Battery className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">Efficiency Rating</p>
              <p className="text-lg font-semibold">B+</p>
            </div>
          </div>
        </div>
        
        <div className="card bg-white dark:bg-neutral-800 p-4">
          <div className="flex items-center">
            <div className="p-2 rounded-lg bg-neutral-100 dark:bg-neutral-700 text-neutral-600 dark:text-neutral-400 mr-3">
              <Clock className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">Last Updated</p>
              <p className="text-lg font-semibold">Just now</p>
            </div>
          </div>
        </div>
      </div>

      {/* Search bar and filters */}
      <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
        <div className="relative flex-1">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-neutral-400" />
          </div>
          <input
            type="text"
            placeholder="Search devices by name or location..."
            className="input pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex space-x-2">
          <select className="input max-w-xs">
            <option>All Locations</option>
            <option>Kitchen</option>
            <option>Living Room</option>
            <option>Bedroom</option>
            <option>Office</option>
          </select>
          <button className="btn btn-secondary">
            <Settings className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Devices list */}
      <div className="card overflow-hidden">
        <DeviceList 
          devices={filteredDevices} 
          onDeviceClick={handleDeviceClick}
        />
      </div>
      
      {/* Device detail modal */}
      {showDeviceDetail && selectedDevice && (
        <div className="fixed inset-0 z-50 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 bg-neutral-900/75 transition-opacity" aria-hidden="true" onClick={() => setShowDeviceDetail(false)}></div>
            
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            
            <div className="inline-block align-bottom bg-white dark:bg-neutral-800 rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <div className="px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div className="sm:flex sm:items-start">
                  <div className="mt-3 sm:mt-0 sm:ml-4 sm:text-left w-full">
                    <h3 className="text-lg leading-6 font-medium text-neutral-900 dark:text-white" id="modal-title">
                      {selectedDevice.name}
                    </h3>
                    
                    <div className="mt-4 grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-neutral-500 dark:text-neutral-400">Status</p>
                        <p className="text-base font-medium flex items-center mt-1">
                          <span className={`inline-block h-2 w-2 rounded-full mr-2 ${
                            selectedDevice.isOn ? 'bg-success-500' : 'bg-neutral-400'
                          }`}></span>
                          {selectedDevice.isOn ? 'Active' : 'Inactive'}
                        </p>
                      </div>
                      
                      <div>
                        <p className="text-sm text-neutral-500 dark:text-neutral-400">Location</p>
                        <p className="text-base font-medium mt-1">{selectedDevice.location}</p>
                      </div>
                      
                      <div>
                        <p className="text-sm text-neutral-500 dark:text-neutral-400">Power Consumption</p>
                        <p className="text-base font-medium mt-1">
                          {selectedDevice.isOn ? `${selectedDevice.watts}W` : '0W'}
                        </p>
                      </div>
                      
                      <div>
                        <p className="text-sm text-neutral-500 dark:text-neutral-400">Energy Efficiency</p>
                        <p className="text-base font-medium mt-1">{selectedDevice.energyEfficiency}</p>
                      </div>
                    </div>
                    
                    <div className="mt-6">
                      <p className="text-sm text-neutral-500 dark:text-neutral-400">Daily Energy Usage</p>
                      <div className="bg-neutral-100 dark:bg-neutral-700 h-24 rounded-lg mt-2 flex items-end px-2">
                        {/* Simplified chart bars */}
                        {[...Array(24)].map((_, i) => {
                          const height = selectedDevice.isOn ? 
                            Math.max(15, Math.random() * 70) :
                            Math.max(5, Math.random() * 15);
                            
                          return (
                            <div
                              key={i}
                              className={`w-full mx-0.5 rounded-t ${
                                selectedDevice.isOn ? 'bg-primary-500' : 'bg-neutral-300 dark:bg-neutral-600'
                              }`}
                              style={{ height: `${height}%` }}
                            ></div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-neutral-100 dark:bg-neutral-700 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button
                  type="button"
                  className="btn btn-primary w-full sm:w-auto sm:ml-3"
                >
                  {selectedDevice.isOn ? 'Turn Off' : 'Turn On'}
                </button>
                <button
                  type="button"
                  className="btn btn-secondary w-full sm:w-auto mt-3 sm:mt-0"
                  onClick={() => setShowDeviceDetail(false)}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Devices;