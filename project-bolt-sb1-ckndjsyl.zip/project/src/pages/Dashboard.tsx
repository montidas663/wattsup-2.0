import React, { useState } from 'react';
import { useEnergyData } from '../contexts/EnergyDataContext';
import EnergyUsageMeter from '../components/EnergyUsageMeter';
import UsageChart from '../components/UsageChart';
import UsageBreakdown from '../components/UsageBreakdown';
import AnomalyAlerts from '../components/AnomalyAlerts';
import EnergyTips from '../components/EnergyTips';
import { Zap, Calendar, RefreshCcw, TrendingUp, TrendingDown, DollarSign } from 'lucide-react';

const Dashboard: React.FC = () => {
  const { 
    currentUsage, 
    dailyUsage,
    weeklyUsage,
    deviceUsage,
    tips,
    anomalies,
    refreshData,
    isLoading
  } = useEnergyData();
  
  const [timeframe, setTimeframe] = useState<'daily' | 'weekly' | 'monthly' | 'yearly'>('daily');
  
  // Get data for the selected timeframe
  const getTimeframeData = () => {
    switch (timeframe) {
      case 'daily':
        return dailyUsage;
      case 'weekly':
        return weeklyUsage;
      case 'monthly':
        return weeklyUsage;
      case 'yearly':
        return weeklyUsage;
      default:
        return dailyUsage;
    }
  };
  
  // Calculate month-over-month change
  const calculateMonthlyChange = () => {
    const currentMonth = currentUsage.monthlyTotal;
    const prevMonth = currentMonth * 0.9; // This would be actual historical data in a real app
    const percentChange = ((currentMonth - prevMonth) / prevMonth) * 100;
    
    return {
      value: percentChange,
      isIncrease: percentChange > 0,
      text: `${Math.abs(percentChange).toFixed(1)}% ${percentChange > 0 ? 'increase' : 'decrease'} from last month`
    };
  };
  
  const monthlyChange = calculateMonthlyChange();

  return (
    <div className="space-y-6">
      {/* Dashboard header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4">
        <div>
          <h2 className="text-2xl font-bold">Energy Dashboard</h2>
          <p className="text-neutral-500 dark:text-neutral-400 mt-1">
            Track and optimize your energy usage in real-time
          </p>
        </div>
        <button 
          onClick={refreshData}
          disabled={isLoading}
          className="btn btn-primary mt-3 sm:mt-0 flex items-center"
        >
          <RefreshCcw className="h-4 w-4 mr-2" />
          {isLoading ? 'Updating...' : 'Refresh Data'}
        </button>
      </div>

      {/* Key metrics row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="card p-4 bg-white dark:bg-neutral-800">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-primary-100 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 mr-4">
              <Zap className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">Current Power</p>
              <p className="text-xl font-semibold">{currentUsage.watts.toLocaleString()} W</p>
            </div>
          </div>
        </div>
        
        <div className="card p-4 bg-white dark:bg-neutral-800">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-secondary-100 dark:bg-secondary-900/20 text-secondary-600 dark:text-secondary-400 mr-4">
              <Calendar className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">This Month</p>
              <p className="text-xl font-semibold">{currentUsage.monthlyTotal.toFixed(1)} kWh</p>
            </div>
          </div>
        </div>
        
        <div className="card p-4 bg-white dark:bg-neutral-800">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-accent-100 dark:bg-accent-900/20 text-accent-600 dark:text-accent-400 mr-4">
              <DollarSign className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">Monthly Cost</p>
              <p className="text-xl font-semibold">${currentUsage.monthlyCost.toFixed(2)}</p>
            </div>
          </div>
        </div>
        
        <div className="card p-4 bg-white dark:bg-neutral-800">
          <div className="flex items-center">
            <div className={`p-3 rounded-full ${monthlyChange.isIncrease 
              ? 'bg-error-100 dark:bg-error-900/20 text-error-600 dark:text-error-400' 
              : 'bg-success-100 dark:bg-success-900/20 text-success-600 dark:text-success-400'} mr-4`}>
              {monthlyChange.isIncrease ? <TrendingUp className="h-6 w-6" /> : <TrendingDown className="h-6 w-6" />}
            </div>
            <div>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">Monthly Trend</p>
              <p className={`text-sm font-medium ${monthlyChange.isIncrease ? 'text-error-500' : 'text-success-500'}`}>
                {monthlyChange.text}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main dashboard grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left column - Usage meter and device breakdown */}
        <div className="space-y-6">
          <EnergyUsageMeter />
          <UsageBreakdown deviceUsage={deviceUsage} />
        </div>
        
        {/* Middle column - Charts */}
        <div className="space-y-6">
          <div className="card h-full">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Energy Usage Trends</h3>
              <div className="inline-flex rounded-md shadow-sm">
                <button
                  type="button"
                  onClick={() => setTimeframe('daily')}
                  className={`px-3 py-1.5 text-xs font-medium rounded-l-lg ${
                    timeframe === 'daily'
                      ? 'bg-primary-500 text-white'
                      : 'bg-white dark:bg-neutral-700 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-600'
                  }`}
                >
                  Daily
                </button>
                <button
                  type="button"
                  onClick={() => setTimeframe('weekly')}
                  className={`px-3 py-1.5 text-xs font-medium ${
                    timeframe === 'weekly'
                      ? 'bg-primary-500 text-white'
                      : 'bg-white dark:bg-neutral-700 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-600'
                  }`}
                >
                  Weekly
                </button>
                <button
                  type="button"
                  onClick={() => setTimeframe('monthly')}
                  className={`px-3 py-1.5 text-xs font-medium rounded-r-lg ${
                    timeframe === 'monthly'
                      ? 'bg-primary-500 text-white'
                      : 'bg-white dark:bg-neutral-700 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-600'
                  }`}
                >
                  Monthly
                </button>
              </div>
            </div>
            <UsageChart 
              data={getTimeframeData()} 
              timeframe={timeframe}
              showCost
            />
          </div>
        </div>
        
        {/* Right column - Anomalies and tips */}
        <div className="space-y-6">
          <AnomalyAlerts anomalies={anomalies} />
          <div className="card">
            <h3 className="text-lg font-semibold mb-4">Energy Saving Tips</h3>
            <EnergyTips tips={tips} limit={3} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;