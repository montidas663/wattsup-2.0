import React, { useState } from 'react';
import { useUser } from '../contexts/UserContext';
import { useTheme } from '../contexts/ThemeContext';
import { 
  User, 
  Bell, 
  Shield, 
  Home, 
  Settings as SettingsIcon,
  HelpCircle,
  Moon,
  Sun,
  Save,
  Upload
} from 'lucide-react';

const Settings: React.FC = () => {
  const { user, updateUser } = useUser();
  const { theme, toggleTheme } = useTheme();
  
  const [activeTab, setActiveTab] = useState('profile');
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    location: user?.location || '',
    homeSize: user?.homeSize || 0,
    numOccupants: user?.numOccupants || 0,
    energyGoal: user?.energyGoal || 0,
  });
  
  // Notification settings
  const [notifications, setNotifications] = useState({
    emailAlerts: true,
    usageReports: true,
    tipsAndRecommendations: true,
    anomalyDetection: true,
  });
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target;
    
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) || 0 : value,
    }));
  };
  
  const handleNotificationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setNotifications(prev => ({
      ...prev,
      [name]: checked,
    }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateUser({
      name: formData.name,
      location: formData.location,
      homeSize: formData.homeSize,
      numOccupants: formData.numOccupants,
      energyGoal: formData.energyGoal,
    });
    
    // Show a success message (in a real app)
    alert('Settings updated successfully!');
  };
  
  const tabs = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'home', label: 'Home Details', icon: Home },
    { id: 'preferences', label: 'Preferences', icon: SettingsIcon },
    { id: 'help', label: 'Help & Support', icon: HelpCircle },
  ];

  return (
    <div className="flex flex-col md:flex-row space-y-6 md:space-y-0 md:space-x-6">
      {/* Sidebar */}
      <div className="md:w-64 bg-white dark:bg-neutral-800 rounded-xl shadow-sm border border-neutral-200 dark:border-neutral-700 overflow-hidden">
        <nav className="flex flex-col">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              className={`flex items-center px-4 py-3 text-sm font-medium ${
                activeTab === tab.id 
                  ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 border-l-4 border-primary-500' 
                  : 'text-neutral-600 dark:text-neutral-300 hover:bg-neutral-50 dark:hover:bg-neutral-700'
              }`}
              onClick={() => setActiveTab(tab.id)}
            >
              <tab.icon className="h-5 w-5 mr-3" />
              {tab.label}
            </button>
          ))}
        </nav>
      </div>
      
      {/* Content area */}
      <div className="flex-1 bg-white dark:bg-neutral-800 rounded-xl shadow-sm border border-neutral-200 dark:border-neutral-700 p-6">
        {activeTab === 'profile' && (
          <div>
            <h2 className="text-xl font-semibold mb-6">Profile Settings</h2>
            
            <div className="flex flex-col sm:flex-row gap-6">
              {/* Avatar */}
              <div className="flex flex-col items-center">
                <div className="h-24 w-24 rounded-full overflow-hidden bg-neutral-200 dark:bg-neutral-700">
                  <img
                    src={user?.avatarUrl}
                    alt={user?.name}
                    className="h-full w-full object-cover"
                  />
                </div>
                <button className="mt-3 btn btn-secondary text-sm px-3 py-1.5">
                  <Upload className="h-4 w-4 mr-1" />
                  Change Photo
                </button>
              </div>
              
              {/* Profile form */}
              <div className="flex-1">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                      Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className="input"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      disabled
                      className="input opacity-70 cursor-not-allowed"
                    />
                    <p className="text-xs text-neutral-500 mt-1">Contact support to change your email address.</p>
                  </div>
                  
                  <div>
                    <label htmlFor="location" className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                      Location
                    </label>
                    <input
                      type="text"
                      id="location"
                      name="location"
                      value={formData.location}
                      onChange={handleChange}
                      className="input"
                    />
                  </div>
                  
                  <div className="pt-4 flex justify-end">
                    <button type="submit" className="btn btn-primary">
                      <Save className="h-4 w-4 mr-2" />
                      Save Changes
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}
        
        {activeTab === 'notifications' && (
          <div>
            <h2 className="text-xl font-semibold mb-6">Notification Settings</h2>
            
            <div className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium text-neutral-900 dark:text-white">Email Alerts</h3>
                    <p className="text-sm text-neutral-500 dark:text-neutral-400">
                      Receive alerts via email for important events
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      name="emailAlerts"
                      checked={notifications.emailAlerts}
                      onChange={handleNotificationChange}
                      className="sr-only peer" 
                    />
                    <div className="w-11 h-6 bg-neutral-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 dark:peer-focus:ring-primary-800 rounded-full peer dark:bg-neutral-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-neutral-600 peer-checked:bg-primary-500"></div>
                  </label>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium text-neutral-900 dark:text-white">Weekly Usage Reports</h3>
                    <p className="text-sm text-neutral-500 dark:text-neutral-400">
                      Get a summary of your energy usage every week
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      name="usageReports"
                      checked={notifications.usageReports}
                      onChange={handleNotificationChange}
                      className="sr-only peer" 
                    />
                    <div className="w-11 h-6 bg-neutral-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 dark:peer-focus:ring-primary-800 rounded-full peer dark:bg-neutral-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-neutral-600 peer-checked:bg-primary-500"></div>
                  </label>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium text-neutral-900 dark:text-white">Energy Saving Tips</h3>
                    <p className="text-sm text-neutral-500 dark:text-neutral-400">
                      Receive personalized recommendations to save energy
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      name="tipsAndRecommendations"
                      checked={notifications.tipsAndRecommendations}
                      onChange={handleNotificationChange}
                      className="sr-only peer" 
                    />
                    <div className="w-11 h-6 bg-neutral-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 dark:peer-focus:ring-primary-800 rounded-full peer dark:bg-neutral-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-neutral-600 peer-checked:bg-primary-500"></div>
                  </label>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium text-neutral-900 dark:text-white">Anomaly Detection</h3>
                    <p className="text-sm text-neutral-500 dark:text-neutral-400">
                      Alert me when unusual energy usage is detected
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      name="anomalyDetection"
                      checked={notifications.anomalyDetection}
                      onChange={handleNotificationChange}
                      className="sr-only peer" 
                    />
                    <div className="w-11 h-6 bg-neutral-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 dark:peer-focus:ring-primary-800 rounded-full peer dark:bg-neutral-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-neutral-600 peer-checked:bg-primary-500"></div>
                  </label>
                </div>
              </div>
              
              <div className="pt-4 flex justify-end">
                <button className="btn btn-primary">
                  <Save className="h-4 w-4 mr-2" />
                  Save Preferences
                </button>
              </div>
            </div>
          </div>
        )}
        
        {activeTab === 'home' && (
          <div>
            <h2 className="text-xl font-semibold mb-6">Home Details</h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="homeSize" className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                  Home Size (square feet)
                </label>
                <input
                  type="number"
                  id="homeSize"
                  name="homeSize"
                  value={formData.homeSize}
                  onChange={handleChange}
                  className="input"
                />
              </div>
              
              <div>
                <label htmlFor="numOccupants" className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                  Number of Occupants
                </label>
                <input
                  type="number"
                  id="numOccupants"
                  name="numOccupants"
                  value={formData.numOccupants}
                  onChange={handleChange}
                  className="input"
                />
              </div>
              
              <div>
                <label htmlFor="energyGoal" className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                  Daily Energy Goal (kWh)
                </label>
                <input
                  type="number"
                  id="energyGoal"
                  name="energyGoal"
                  value={formData.energyGoal}
                  onChange={handleChange}
                  className="input"
                />
                <p className="text-xs text-neutral-500 mt-1">
                  The recommended daily consumption for your home size is approximately {(formData.homeSize * 0.5 / 30).toFixed(1)} kWh.
                </p>
              </div>
              
              <div className="pt-4 flex justify-end">
                <button type="submit" className="btn btn-primary">
                  <Save className="h-4 w-4 mr-2" />
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        )}
        
        {activeTab === 'preferences' && (
          <div>
            <h2 className="text-xl font-semibold mb-6">App Preferences</h2>
            
            <div className="space-y-6">
              {/* Theme preference */}
              <div>
                <h3 className="text-md font-medium mb-2">Theme</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    className={`border rounded-lg p-4 flex items-center ${
                      theme === 'light'
                        ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20'
                        : 'border-neutral-200 dark:border-neutral-700'
                    }`}
                    onClick={() => theme !== 'light' && toggleTheme()}
                  >
                    <div className="mr-3 p-2 bg-white rounded-full shadow">
                      <Sun className="h-5 w-5 text-warning-500" />
                    </div>
                    <div className="text-left">
                      <div className="font-medium">Light Mode</div>
                      <div className="text-xs text-neutral-500 dark:text-neutral-400">
                        Bright theme for daytime use
                      </div>
                    </div>
                    {theme === 'light' && (
                      <div className="ml-auto h-5 w-5 rounded-full bg-primary-500 flex items-center justify-center">
                        <svg className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                    )}
                  </button>
                  
                  <button
                    className={`border rounded-lg p-4 flex items-center ${
                      theme === 'dark'
                        ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20'
                        : 'border-neutral-200 dark:border-neutral-700'
                    }`}
                    onClick={() => theme !== 'dark' && toggleTheme()}
                  >
                    <div className="mr-3 p-2 bg-neutral-800 rounded-full shadow">
                      <Moon className="h-5 w-5 text-neutral-300" />
                    </div>
                    <div className="text-left">
                      <div className="font-medium">Dark Mode</div>
                      <div className="text-xs text-neutral-500 dark:text-neutral-400">
                        Darker theme for low light
                      </div>
                    </div>
                    {theme === 'dark' && (
                      <div className="ml-auto h-5 w-5 rounded-full bg-primary-500 flex items-center justify-center">
                        <svg className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                    )}
                  </button>
                </div>
              </div>
              
              {/* Units preference */}
              <div>
                <h3 className="text-md font-medium mb-2">Energy Units</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    className="border border-primary-500 bg-primary-50 dark:bg-primary-900/20 rounded-lg p-4 flex items-center"
                  >
                    <div className="mr-3 p-2 bg-white dark:bg-neutral-800 rounded-full shadow">
                      <Zap className="h-5 w-5 text-primary-500" />
                    </div>
                    <div className="text-left">
                      <div className="font-medium">Kilowatt-hours (kWh)</div>
                      <div className="text-xs text-neutral-500 dark:text-neutral-400">
                        Standard energy measurement
                      </div>
                    </div>
                    <div className="ml-auto h-5 w-5 rounded-full bg-primary-500 flex items-center justify-center">
                      <svg className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                  </button>
                  
                  <button
                    className="border border-neutral-200 dark:border-neutral-700 rounded-lg p-4 flex items-center"
                    disabled
                  >
                    <div className="mr-3 p-2 bg-white dark:bg-neutral-800 rounded-full shadow">
                      <Zap className="h-5 w-5 text-neutral-400" />
                    </div>
                    <div className="text-left">
                      <div className="font-medium text-neutral-400">BTU</div>
                      <div className="text-xs text-neutral-500 dark:text-neutral-400">
                        Coming soon
                      </div>
                    </div>
                  </button>
                </div>
              </div>
              
              <div className="pt-4 flex justify-end">
                <button className="btn btn-primary">
                  <Save className="h-4 w-4 mr-2" />
                  Save Preferences
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Settings;