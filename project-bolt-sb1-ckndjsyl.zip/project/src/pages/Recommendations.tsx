import React, { useState } from 'react';
import { useEnergyData } from '../contexts/EnergyDataContext';
import EnergyTips from '../components/EnergyTips';
import { 
  Filter, 
  Lightbulb, 
  DollarSign, 
  ThermometerSun,
  Sliders,
  ArrowUpRight,
  ArrowDownRight,
  LineChart,
  CheckSquare 
} from 'lucide-react';

const Recommendations: React.FC = () => {
  const { tips, currentUsage } = useEnergyData();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('all');
  
  // Filter tips based on selections
  const filteredTips = tips.filter(tip => {
    const categoryMatch = selectedCategory === 'all' || tip.category === selectedCategory;
    const difficultyMatch = selectedDifficulty === 'all' || tip.difficulty === selectedDifficulty;
    return categoryMatch && difficultyMatch;
  });
  
  // Calculate total potential savings
  const totalSavings = filteredTips.reduce((total, tip) => total + tip.potentialSavings, 0);
  
  // Mock implementation statuses
  const completedCount = 2;
  const inProgressCount = 1;
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4">
        <div>
          <h2 className="text-2xl font-bold">Energy Saving Recommendations</h2>
          <p className="text-neutral-500 dark:text-neutral-400 mt-1">
            Personalized tips to reduce your energy consumption and costs
          </p>
        </div>
      </div>
      
      {/* Summary cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="card p-4 bg-white dark:bg-neutral-800">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-primary-100 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 mr-3">
              <DollarSign className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">Potential Savings</p>
              <p className="text-xl font-semibold">${totalSavings}/year</p>
            </div>
          </div>
        </div>
        
        <div className="card p-4 bg-white dark:bg-neutral-800">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-success-100 dark:bg-success-900/20 text-success-600 dark:text-success-400 mr-3">
              <CheckSquare className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">Implemented</p>
              <p className="text-xl font-semibold">{completedCount} tips</p>
            </div>
          </div>
        </div>
        
        <div className="card p-4 bg-white dark:bg-neutral-800">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-warning-100 dark:bg-warning-900/20 text-warning-600 dark:text-warning-400 mr-3">
              <Sliders className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">In Progress</p>
              <p className="text-xl font-semibold">{inProgressCount} tips</p>
            </div>
          </div>
        </div>
        
        <div className="card p-4 bg-white dark:bg-neutral-800">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-secondary-100 dark:bg-secondary-900/20 text-secondary-600 dark:text-secondary-400 mr-3">
              <LineChart className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">Efficiency Target</p>
              <p className="text-xl font-semibold">{(currentUsage.dailyGoal * 30).toFixed(0)} kWh</p>
              <p className="text-xs text-neutral-500 dark:text-neutral-400">monthly goal</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Filters */}
      <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 justify-between">
        <div className="flex items-center space-x-2">
          <Filter className="h-5 w-5 text-neutral-500" />
          <span className="text-sm font-medium">Filter by:</span>
        </div>
        
        <div className="flex space-x-2 overflow-x-auto pb-2">
          <button
            className={`px-3 py-1.5 text-xs font-medium rounded-full ${
              selectedCategory === 'all'
                ? 'bg-primary-500 text-white'
                : 'bg-white dark:bg-neutral-700 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-600'
            }`}
            onClick={() => setSelectedCategory('all')}
          >
            All Categories
          </button>
          <button
            className={`px-3 py-1.5 text-xs font-medium rounded-full flex items-center ${
              selectedCategory === 'lighting'
                ? 'bg-primary-500 text-white'
                : 'bg-white dark:bg-neutral-700 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-600'
            }`}
            onClick={() => setSelectedCategory('lighting')}
          >
            <Lightbulb className="h-3 w-3 mr-1" />
            Lighting
          </button>
          <button
            className={`px-3 py-1.5 text-xs font-medium rounded-full flex items-center ${
              selectedCategory === 'hvac'
                ? 'bg-primary-500 text-white'
                : 'bg-white dark:bg-neutral-700 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-600'
            }`}
            onClick={() => setSelectedCategory('hvac')}
          >
            <ThermometerSun className="h-3 w-3 mr-1" />
            HVAC
          </button>
          <button
            className={`px-3 py-1.5 text-xs font-medium rounded-full flex items-center ${
              selectedCategory === 'appliance'
                ? 'bg-primary-500 text-white'
                : 'bg-white dark:bg-neutral-700 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-600'
            }`}
            onClick={() => setSelectedCategory('appliance')}
          >
            <Sliders className="h-3 w-3 mr-1" />
            Appliances
          </button>
          <button
            className={`px-3 py-1.5 text-xs font-medium rounded-full ${
              selectedCategory === 'general'
                ? 'bg-primary-500 text-white'
                : 'bg-white dark:bg-neutral-700 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-600'
            }`}
            onClick={() => setSelectedCategory('general')}
          >
            General
          </button>
        </div>
        
        <div className="flex space-x-2">
          <select
            className="input max-w-xs"
            value={selectedDifficulty}
            onChange={(e) => setSelectedDifficulty(e.target.value)}
          >
            <option value="all">All Difficulties</option>
            <option value="easy">Easy</option>
            <option value="medium">Medium</option>
            <option value="hard">Hard</option>
          </select>
        </div>
      </div>
      
      {/* Recommended actions */}
      <div>
        <EnergyTips tips={filteredTips} />
      </div>
      
      {/* Energy savings projection */}
      <div className="card p-6 bg-gradient-to-r from-primary-500/10 to-secondary-500/10 dark:from-primary-900/20 dark:to-secondary-900/20 border border-primary-200 dark:border-primary-900/50">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div>
            <h3 className="text-lg font-semibold mb-2">Your Savings Potential</h3>
            <p className="text-neutral-700 dark:text-neutral-300">
              Implementing all recommendations could save you up to:
            </p>
            <div className="mt-3 flex items-center">
              <ArrowDownRight className="h-6 w-6 text-success-500 mr-2" />
              <span className="text-3xl font-bold text-success-600 dark:text-success-400">
                ${totalSavings}/year
              </span>
            </div>
            <p className="text-sm text-neutral-500 dark:text-neutral-400 mt-2">
              That's {((totalSavings / (currentUsage.monthlyCost * 12)) * 100).toFixed(0)}% of your current annual energy costs
            </p>
          </div>
          
          <div className="mt-6 md:mt-0 bg-white dark:bg-neutral-800 p-4 rounded-lg shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <div className="font-medium">Current Monthly Bill</div>
              <div className="font-bold">${currentUsage.monthlyCost.toFixed(2)}</div>
            </div>
            <div className="flex items-center justify-between mb-2">
              <div className="font-medium">Potential Monthly Bill</div>
              <div className="font-bold text-success-500">
                ${(currentUsage.monthlyCost - (totalSavings / 12)).toFixed(2)}
              </div>
            </div>
            <div className="flex items-center justify-between pt-2 border-t border-neutral-200 dark:border-neutral-700">
              <div className="font-medium">Monthly Savings</div>
              <div className="font-bold text-success-600 dark:text-success-400">
                ${(totalSavings / 12).toFixed(2)}
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Implementation roadmap */}
      <div className="card p-6">
        <h3 className="text-lg font-semibold mb-4">Implementation Roadmap</h3>
        
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-neutral-200 dark:bg-neutral-700"></div>
          
          <div className="space-y-6 relative">
            <div className="flex">
              <div className="flex-shrink-0 h-8 w-8 rounded-full bg-success-500 flex items-center justify-center z-10">
                <CheckSquare className="h-4 w-4 text-white" />
              </div>
              <div className="ml-4 bg-white dark:bg-neutral-800 p-4 rounded-lg border border-neutral-200 dark:border-neutral-700 flex-1">
                <h4 className="font-medium">Step 1: Quick Wins (Now)</h4>
                <p className="text-sm text-neutral-600 dark:text-neutral-300 mt-1">
                  Focus on easy, immediate changes like LED bulbs, unplugging idle devices, and adjusting thermostat settings.
                </p>
                <div className="mt-2 bg-success-500/10 text-success-500 text-xs px-2 py-1 rounded inline-flex items-center">
                  <CheckSquare className="h-3 w-3 mr-1" />
                  Completed
                </div>
              </div>
            </div>
            
            <div className="flex">
              <div className="flex-shrink-0 h-8 w-8 rounded-full bg-warning-500 flex items-center justify-center z-10">
                <Sliders className="h-4 w-4 text-white" />
              </div>
              <div className="ml-4 bg-white dark:bg-neutral-800 p-4 rounded-lg border border-neutral-200 dark:border-neutral-700 flex-1">
                <h4 className="font-medium">Step 2: Optimization (1-3 months)</h4>
                <p className="text-sm text-neutral-600 dark:text-neutral-300 mt-1">
                  Configure device schedules, install smart plugs, and optimize appliance usage patterns.
                </p>
                <div className="mt-2 bg-warning-500/10 text-warning-500 text-xs px-2 py-1 rounded inline-flex items-center">
                  <Clock className="h-3 w-3 mr-1" />
                  In Progress
                </div>
              </div>
            </div>
            
            <div className="flex">
              <div className="flex-shrink-0 h-8 w-8 rounded-full bg-neutral-300 dark:bg-neutral-700 flex items-center justify-center z-10">
                <ArrowUpRight className="h-4 w-4 text-neutral-600 dark:text-neutral-400" />
              </div>
              <div className="ml-4 bg-white dark:bg-neutral-800 p-4 rounded-lg border border-neutral-200 dark:border-neutral-700 flex-1">
                <h4 className="font-medium">Step 3: Upgrades (3-12 months)</h4>
                <p className="text-sm text-neutral-600 dark:text-neutral-300 mt-1">
                  Replace inefficient appliances, consider energy-efficient HVAC systems, and improve home insulation.
                </p>
                <div className="mt-2 bg-neutral-200 dark:bg-neutral-700 text-neutral-600 dark:text-neutral-400 text-xs px-2 py-1 rounded inline-flex items-center">
                  <Calendar className="h-3 w-3 mr-1" />
                  Upcoming
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Recommendations;