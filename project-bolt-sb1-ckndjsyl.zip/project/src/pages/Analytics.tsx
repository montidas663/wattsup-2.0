import React, { useState } from 'react';
import { useEnergyData } from '../contexts/EnergyDataContext';
import UsageChart from '../components/UsageChart';
import { Calendar, TrendingUp, DollarSign, CalendarDays, LineChart } from 'lucide-react';

const Analytics: React.FC = () => {
  const { 
    dailyUsage,
    weeklyUsage, 
    monthlyUsage, 
    yearlyUsage,
    currentUsage
  } = useEnergyData();
  
  const [timeRange, setTimeRange] = useState<'daily' | 'weekly' | 'monthly' | 'yearly'>('daily');
  const [comparisonType, setComparisonType] = useState<'usage' | 'cost'>('usage');
  
  // Calculate metrics based on selected timeframe
  const getUsageData = () => {
    switch(timeRange) {
      case 'daily':
        return dailyUsage;
      case 'weekly':
        return weeklyUsage;
      case 'monthly':
        return monthlyUsage;
      case 'yearly':
        return yearlyUsage;
      default:
        return dailyUsage;
    }
  };
  
  // Get recent trend
  const getRecentTrend = () => {
    const data = getUsageData();
    if (data.length < 2) return 0;
    
    const latest = data[data.length - 1];
    const previous = data[data.length - 2];
    
    if (comparisonType === 'usage') {
      return ((latest.kWh - previous.kWh) / previous.kWh) * 100;
    } else {
      return ((latest.cost - previous.cost) / previous.cost) * 100;
    }
  };
  
  // Calculate average
  const getAverage = () => {
    const data = getUsageData();
    if (data.length === 0) return 0;
    
    if (comparisonType === 'usage') {
      const sum = data.reduce((acc, curr) => acc + curr.kWh, 0);
      return sum / data.length;
    } else {
      const sum = data.reduce((acc, curr) => acc + curr.cost, 0);
      return sum / data.length;
    }
  };
  
  // Calculate peak
  const getPeak = () => {
    const data = getUsageData();
    if (data.length === 0) return 0;
    
    if (comparisonType === 'usage') {
      return Math.max(...data.map(item => item.kWh));
    } else {
      return Math.max(...data.map(item => item.cost));
    }
  };
  
  const trend = getRecentTrend();
  const average = getAverage();
  const peak = getPeak();

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4">
        <div>
          <h2 className="text-2xl font-bold">Energy Analytics</h2>
          <p className="text-neutral-500 dark:text-neutral-400 mt-1">
            Detailed analysis of your energy consumption patterns
          </p>
        </div>
        
        <div className="mt-3 sm:mt-0 flex space-x-2">
          <select 
            className="input max-w-xs"
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value as any)}
          >
            <option value="daily">Daily View</option>
            <option value="weekly">Weekly View</option>
            <option value="monthly">Monthly View</option>
            <option value="yearly">Yearly View</option>
          </select>
          
          <select 
            className="input max-w-xs"
            value={comparisonType}
            onChange={(e) => setComparisonType(e.target.value as any)}
          >
            <option value="usage">Energy Usage</option>
            <option value="cost">Cost Analysis</option>
          </select>
        </div>
      </div>
      
      {/* Stats cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="card p-4">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400 mr-3">
              <LineChart className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">Average {comparisonType === 'usage' ? 'Usage' : 'Cost'}</p>
              <p className="text-xl font-semibold">
                {comparisonType === 'usage' 
                  ? `${average.toFixed(2)} kWh` 
                  : `$${average.toFixed(2)}`
                }
              </p>
              <p className="text-xs text-neutral-500 dark:text-neutral-400">
                per {timeRange === 'daily' ? 'day' : timeRange === 'weekly' ? 'week' : timeRange === 'monthly' ? 'month' : 'year'}
              </p>
            </div>
          </div>
        </div>
        
        <div className="card p-4">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-secondary-100 dark:bg-secondary-900/30 text-secondary-600 dark:text-secondary-400 mr-3">
              <TrendingUp className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">Recent Trend</p>
              <p className={`text-xl font-semibold ${
                trend > 0 ? 'text-error-500' : trend < 0 ? 'text-success-500' : 'text-neutral-500'
              }`}>
                {trend > 0 ? '+' : ''}{trend.toFixed(1)}%
              </p>
              <p className="text-xs text-neutral-500 dark:text-neutral-400">
                compared to previous period
              </p>
            </div>
          </div>
        </div>
        
        <div className="card p-4">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-accent-100 dark:bg-accent-900/30 text-accent-600 dark:text-accent-400 mr-3">
              {comparisonType === 'usage' ? <Calendar className="h-6 w-6" /> : <DollarSign className="h-6 w-6" />}
            </div>
            <div>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">Peak {comparisonType === 'usage' ? 'Usage' : 'Expense'}</p>
              <p className="text-xl font-semibold">
                {comparisonType === 'usage' 
                  ? `${peak.toFixed(2)} kWh` 
                  : `$${peak.toFixed(2)}`
                }
              </p>
              <p className="text-xs text-neutral-500 dark:text-neutral-400">
                highest recorded value
              </p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Main chart section */}
      <div className="card p-6">
        <h3 className="text-lg font-semibold mb-4">
          {comparisonType === 'usage' ? 'Energy Consumption' : 'Cost Analysis'}
        </h3>
        <div className="h-96">
          <UsageChart 
            data={getUsageData()} 
            timeframe={timeRange}
            showCost={comparisonType === 'cost'} 
          />
        </div>
        
        <div className="mt-6 border-t border-neutral-200 dark:border-neutral-700 pt-4">
          <h4 className="text-sm font-medium mb-2">Key Insights</h4>
          <ul className="space-y-2 text-sm">
            <li className="flex items-start">
              <div className="flex-shrink-0 h-5 w-5 text-primary-500">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
              </div>
              <p className="ml-2 text-neutral-600 dark:text-neutral-300">
                Your {comparisonType === 'usage' ? 'energy usage' : 'energy costs'} {trend > 0 ? 'increased' : 'decreased'} by {Math.abs(trend).toFixed(1)}% compared to the previous period.
              </p>
            </li>
            <li className="flex items-start">
              <div className="flex-shrink-0 h-5 w-5 text-primary-500">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
              </div>
              <p className="ml-2 text-neutral-600 dark:text-neutral-300">
                Your {timeRange} peak {comparisonType === 'usage' ? 'usage' : 'cost'} is {peak.toFixed(2)} {comparisonType === 'usage' ? 'kWh' : '$'}, which is {((peak / average - 1) * 100).toFixed(0)}% above your average.
              </p>
            </li>
            <li className="flex items-start">
              <div className="flex-shrink-0 h-5 w-5 text-primary-500">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
              </div>
              <p className="ml-2 text-neutral-600 dark:text-neutral-300">
                HVAC systems contribute to approximately 40% of your total energy consumption. Optimizing temperature settings could lead to savings.
              </p>
            </li>
          </ul>
        </div>
      </div>
      
      {/* Additional analytics sections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Time of day usage patterns */}
        <div className="card p-6">
          <h3 className="text-lg font-semibold mb-4">Usage by Time of Day</h3>
          <div className="h-64 flex items-end justify-between px-4">
            {[...Array(24)].map((_, hour) => {
              // Generate a pattern of usage by hour - higher during morning and evening
              let height;
              if (hour >= 6 && hour <= 9) { // Morning peak
                height = 60 + Math.random() * 30;
              } else if (hour >= 17 && hour <= 22) { // Evening peak
                height = 70 + Math.random() * 20;
              } else if (hour >= 23 || hour <= 5) { // Night (low)
                height = 20 + Math.random() * 15;
              } else { // Midday (medium)
                height = 35 + Math.random() * 20;
              }
              
              return (
                <div key={hour} className="flex flex-col items-center">
                  <div 
                    className="w-5 bg-primary-500 rounded-t hover:bg-primary-600 transition-all"
                    style={{ height: `${height}%` }}
                  ></div>
                  <div className="text-xs text-neutral-500 dark:text-neutral-400 mt-2">
                    {hour === 0 ? '12am' : hour < 12 ? `${hour}am` : hour === 12 ? '12pm' : `${hour-12}pm`}
                  </div>
                </div>
              );
            })}
          </div>
          <div className="mt-4 text-sm text-neutral-600 dark:text-neutral-300">
            <p>Your peak energy usage occurs between 6-9am and 5-10pm, which aligns with typical household patterns.</p>
          </div>
        </div>
        
        {/* Seasonal comparison */}
        <div className="card p-6">
          <h3 className="text-lg font-semibold mb-4">Seasonal Comparison</h3>
          <div className="grid grid-cols-4 gap-4 mb-6">
            <div className="text-center">
              <div className="text-xl font-bold text-secondary-500">Winter</div>
              <div className="text-2xl font-medium mt-2">312<span className="text-sm font-normal"> kWh</span></div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold text-success-500">Spring</div>
              <div className="text-2xl font-medium mt-2">276<span className="text-sm font-normal"> kWh</span></div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold text-warning-500">Summer</div>
              <div className="text-2xl font-medium mt-2">358<span className="text-sm font-normal"> kWh</span></div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold text-error-500">Fall</div>
              <div className="text-2xl font-medium mt-2">284<span className="text-sm font-normal"> kWh</span></div>
            </div>
          </div>
          <div className="bg-neutral-100 dark:bg-neutral-700 rounded-lg p-4">
            <h4 className="font-medium mb-2 flex items-center">
              <CalendarDays className="h-4 w-4 mr-1 text-primary-500" />
              Seasonal Insights
            </h4>
            <p className="text-sm text-neutral-600 dark:text-neutral-300">
              Your energy usage peaks during summer months, primarily due to increased HVAC usage. 
              Consider upgrading to more efficient cooling systems or improving insulation to reduce summer consumption.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;