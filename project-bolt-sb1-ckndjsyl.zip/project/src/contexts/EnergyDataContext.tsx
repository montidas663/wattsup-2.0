import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { generateMockEnergyData } from '../utils/mockData';
import { Device, EnergyUsage, DailyUsage, DeviceUsage, EnergyTip } from '../types/energy';

interface EnergyDataContextType {
  currentUsage: EnergyUsage;
  dailyUsage: DailyUsage[];
  weeklyUsage: DailyUsage[];
  monthlyUsage: DailyUsage[];
  yearlyUsage: DailyUsage[];
  devices: Device[];
  deviceUsage: DeviceUsage[];
  tips: EnergyTip[];
  anomalies: any[];
  isLoading: boolean;
  refreshData: () => void;
}

const EnergyDataContext = createContext<EnergyDataContextType | undefined>(undefined);

export const EnergyDataProvider = ({ children }: { children: ReactNode }) => {
  const [data, setData] = useState(() => generateMockEnergyData());
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Simulate periodic data updates
  useEffect(() => {
    const intervalId = setInterval(() => {
      refreshData();
    }, 60000); // Update every minute
    
    return () => clearInterval(intervalId);
  }, []);

  const refreshData = () => {
    setIsLoading(true);
    
    // Simulate an API call delay
    setTimeout(() => {
      const newData = generateMockEnergyData(data);
      setData(newData);
      setIsLoading(false);
    }, 800);
  };

  return (
    <EnergyDataContext.Provider 
      value={{
        currentUsage: data.currentUsage,
        dailyUsage: data.dailyUsage,
        weeklyUsage: data.weeklyUsage,
        monthlyUsage: data.monthlyUsage,
        yearlyUsage: data.yearlyUsage,
        devices: data.devices,
        deviceUsage: data.deviceUsage,
        tips: data.tips,
        anomalies: data.anomalies,
        isLoading,
        refreshData
      }}
    >
      {children}
    </EnergyDataContext.Provider>
  );
};

export const useEnergyData = (): EnergyDataContextType => {
  const context = useContext(EnergyDataContext);
  if (!context) {
    throw new Error('useEnergyData must be used within an EnergyDataProvider');
  }
  return context;
};