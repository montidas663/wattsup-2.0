export interface EnergyUsage {
  watts: number;
  voltage: number;
  amperage: number;
  kWh: number;
  dailyTotal: number;
  dailyGoal: number;
  weeklyTotal: number;
  monthlyTotal: number;
  monthlyCost: number;
}

export interface DailyUsage {
  date: string;
  kWh: number;
  cost: number;
  compared?: number;
}

export interface Device {
  id: string;
  name: string;
  type: 'lighting' | 'hvac' | 'kitchen' | 'entertainment' | 'office' | 'other';
  location: string;
  isOn: boolean;
  watts: number;
  icon: string;
  energyEfficiency: 'A+++' | 'A++' | 'A+' | 'A' | 'B' | 'C' | 'D';
  status: 'normal' | 'high' | 'low' | 'offline';
  lastUpdated: string;
}

export interface DeviceUsage {
  deviceId: string;
  name: string;
  type: string;
  kWh: number;
  percentage: number;
  cost: number;
}

export interface EnergyTip {
  id: string;
  title: string;
  description: string;
  potentialSavings: number;
  difficulty: 'easy' | 'medium' | 'hard';
  icon: string;
  category: 'appliance' | 'lighting' | 'hvac' | 'general';
}

export interface Anomaly {
  id: string;
  deviceId: string;
  deviceName: string;
  timestamp: string;
  description: string;
  severity: 'low' | 'medium' | 'high';
  watts: number;
  normalWatts: number;
  percentageIncrease: number;
  isResolved: boolean;
}